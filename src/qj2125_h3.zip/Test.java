import java.util.*;

public class Test
{
    public static void main(String args[])
    {
        double[] a = new double[2];
        System.out.println(Arrays.toString(a));
    }
}
